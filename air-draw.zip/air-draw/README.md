# Air-Draw ✋🎨

Draw on screen using nothing but your hand and a webcam — no mouse, no stylus.

Air-Draw uses [MediaPipe Hands](https://developers.google.com/mediapipe) to track your hand in real time and [OpenCV](https://opencv.org/) to turn fingertip movement into strokes on a persistent canvas.

## Features
- Real-time hand and fingertip tracking from a webcam feed
- Gesture-based mode switching — no keyboard needed while drawing:
  - ☝️ Index finger up → draw
  - ✌️ Index + middle up → hover over the palette to change color
  - 🖐 Other poses → pen up
- On-screen color palette (red, green, blue, yellow) plus an eraser
- Save your drawing as a PNG at any time

## Tech Stack
- Python 3.9+
- OpenCV
- MediaPipe
- NumPy

## Getting Started

```bash
git clone https://github.com/<your-username>/air-draw.git
cd air-draw
pip install -r requirements.txt
cd src
python air_draw.py
```

## Controls
| Input | Action |
|---|---|
| Index finger up | Draw |
| Index + middle finger up | Hover / pick a color from the palette |
| Any other hand pose | Stop drawing |
| `c` | Clear the canvas |
| `s` | Save the current drawing as a PNG |
| `q` | Quit |

## Project Structure
```
air-draw/
├── src/
│   ├── air_draw.py       # main loop
│   ├── hand_tracker.py   # MediaPipe wrapper + gesture detection
│   └── canvas_manager.py # drawing canvas + color palette
├── requirements.txt
└── README.md
```

## Roadmap
- [ ] Adjustable brush size via a pinch gesture
- [ ] Multi-hand support (two-color simultaneous drawing)
- [ ] Export the drawing process as a timelapse GIF

## Author
**Pinninti Ajay** — [LinkedIn](https://www.linkedin.com/in/pinnintiajay45)

## License
MIT — see [LICENSE](LICENSE).
