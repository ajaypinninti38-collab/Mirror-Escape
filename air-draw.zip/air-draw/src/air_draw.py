"""
Air-Draw - draw in the air using just your hand and a webcam.

Gestures:
  - Index finger only up        -> draw
  - Index + middle finger up    -> hover mode (move over the palette to pick a color)
  - Open palm / other poses     -> pen up / stop drawing

Keyboard:
  - c  -> clear canvas
  - s  -> save the current drawing as a PNG
  - q  -> quit
"""

import time
import cv2

from hand_tracker import HandTracker
from canvas_manager import CanvasManager


def main():
    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

    ok, frame = cap.read()
    if not ok:
        raise RuntimeError("Could not access the webcam.")

    height, width = frame.shape[:2]
    tracker = HandTracker(max_hands=1)
    canvas_mgr = CanvasManager(width, height)

    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frame = cv2.flip(frame, 1)

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = tracker.process(rgb)

        swatch_w = canvas_mgr.draw_palette(frame)

        if result.multi_hand_landmarks:
            hand_landmarks = result.multi_hand_landmarks[0]
            points = tracker.get_landmark_points(hand_landmarks, frame.shape)
            fingers = tracker.fingers_up(points)
            index_tip = points[8]

            _, index_up, middle_up, _, _ = fingers

            if index_up and middle_up:
                # Hover / selection mode - nothing is drawn
                canvas_mgr.release()
                if index_tip[1] < 60:
                    canvas_mgr.pick_color_from_palette(index_tip[0], swatch_w)
                cv2.circle(frame, index_tip, 12, canvas_mgr.color, 2)
            elif index_up and not middle_up:
                # Drawing mode
                canvas_mgr.draw(index_tip)
                cv2.circle(frame, index_tip, 6, canvas_mgr.color, -1)
            else:
                canvas_mgr.release()
        else:
            canvas_mgr.release()

        output = canvas_mgr.merge_with(frame)
        cv2.imshow("Air-Draw", output)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('c'):
            canvas_mgr.clear()
        elif key == ord('s'):
            filename = f"air_draw_{int(time.time())}.png"
            cv2.imwrite(filename, canvas_mgr.canvas)
            print(f"Saved {filename}")

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
