"""Manages the persistent drawing canvas and the on-screen color palette."""

import numpy as np
import cv2

PALETTE = [
    ("Red", (0, 0, 255)),
    ("Green", (0, 200, 0)),
    ("Blue", (255, 0, 0)),
    ("Yellow", (0, 220, 220)),
    ("Eraser", (0, 0, 0)),
]


class CanvasManager:
    def __init__(self, width: int, height: int):
        self.canvas = np.zeros((height, width, 3), dtype=np.uint8)
        self.color = PALETTE[0][1]
        self.brush_size = 8
        self.eraser_size = 40
        self.prev_point = None

    def draw_palette(self, frame):
        """Draw color swatches across the top of the frame. Returns swatch width."""
        swatch_w = frame.shape[1] // len(PALETTE)
        for i, (name, color) in enumerate(PALETTE):
            x1, x2 = i * swatch_w, (i + 1) * swatch_w
            display_color = (60, 60, 60) if color == (0, 0, 0) else color
            cv2.rectangle(frame, (x1, 0), (x2, 60), display_color, -1)
            cv2.putText(frame, name, (x1 + 10, 40), cv2.FONT_HERSHEY_SIMPLEX,
                        0.6, (255, 255, 255), 2)
        return swatch_w

    def pick_color_from_palette(self, x, swatch_w):
        index = min(x // swatch_w, len(PALETTE) - 1)
        self.color = PALETTE[index][1]

    def draw(self, point):
        """Draw a line segment from the previous point to the current point."""
        if self.prev_point is not None:
            size = self.eraser_size if self.color == (0, 0, 0) else self.brush_size
            cv2.line(self.canvas, self.prev_point, point, self.color, size)
        self.prev_point = point

    def release(self):
        self.prev_point = None

    def clear(self):
        self.canvas[:] = 0

    def merge_with(self, frame):
        """Overlay the drawing canvas on top of the live camera frame."""
        gray = cv2.cvtColor(self.canvas, cv2.COLOR_BGR2GRAY)
        _, mask = cv2.threshold(gray, 20, 255, cv2.THRESH_BINARY_INV)
        mask_inv = cv2.bitwise_not(mask)
        background = cv2.bitwise_and(frame, frame, mask=mask)
        foreground = cv2.bitwise_and(self.canvas, self.canvas, mask=mask_inv)
        return cv2.add(background, foreground)
