"""Thin wrapper around MediaPipe Hands for fingertip and gesture detection."""

import mediapipe as mp


class HandTracker:
    def __init__(self, max_hands: int = 1, detection_confidence: float = 0.7,
                 tracking_confidence: float = 0.7):
        self._mp_hands = mp.solutions.hands
        self.hands = self._mp_hands.Hands(
            max_num_hands=max_hands,
            min_detection_confidence=detection_confidence,
            min_tracking_confidence=tracking_confidence,
        )
        self.mp_draw = mp.solutions.drawing_utils

    def process(self, frame_rgb):
        """Run detection on an RGB frame and return the raw MediaPipe result."""
        return self.hands.process(frame_rgb)

    def get_landmark_points(self, hand_landmarks, frame_shape):
        """Convert normalized MediaPipe landmarks into pixel coordinates."""
        h, w = frame_shape[:2]
        return [(int(lm.x * w), int(lm.y * h)) for lm in hand_landmarks.landmark]

    @staticmethod
    def fingers_up(points):
        """
        Return a list of 5 booleans (thumb, index, middle, ring, pinky)
        indicating which fingers are extended, based on landmark positions.
        """
        if not points:
            return [False] * 5

        tips = [4, 8, 12, 16, 20]
        fingers = []

        # Thumb: compare x position (works for a right hand facing the camera)
        fingers.append(points[tips[0]][0] > points[tips[0] - 1][0])

        # Other four fingers: tip above the pip joint means "up"
        for tip in tips[1:]:
            fingers.append(points[tip][1] < points[tip - 2][1])

        return fingers
