# Mirror Escape 🪞

A 2D puzzle-platformer prototype built in **Godot 4**, where you control two characters at once — and one of them mirrors your input.

This repository is a small playable proof-of-concept of the core mechanic from the full game design document (100 levels, monetization plan, and solo-dev scope).

## The Mechanic
Both characters read the *same* input at the same time:
- **Player A** (blue) moves normally.
- **Player B** (orange) moves with horizontal input inverted — press → and A goes right while B goes left.

Every level is really two puzzles happening at once, solved with one set of controls.

## This Prototype
- Two mirrored `CharacterBody2D` players sharing one control scheme
- Simple gravity + jump physics
- Two goal pads, color-matched to their player — the level is "complete" only when **both** characters are standing on their own goal at the same time
- A minimal single-screen level demonstrating the mirror mechanic: both players start on opposite sides and must swap places to finish

## Controls
| Key | Action |
|---|---|
| ← / → | Move (Player B moves opposite) |
| ↑ | Jump (both players) |

## Running the Project
1. Install [Godot 4.2+](https://godotengine.org/download)
2. Clone this repo and open `project.godot` in Godot
3. Press **F5** (or the Play button) to run

> If Godot shows a one-time warning about scene resource IDs on first open, just save the scene (Ctrl+S) — it regenerates automatically and the project runs normally.

## Project Structure
```
mirror-escape/
├── project.godot
├── scenes/
│   ├── main.tscn      # the demo level
│   ├── player.tscn    # mirrored character
│   └── goal.tscn      # goal pad
├── scripts/
│   ├── main.gd
│   ├── player.gd
│   └── goal.gd
└── README.md
```

## Roadmap
This prototype is the foundation for the full design:
- [ ] 100 hand-designed levels of increasing complexity
- [ ] Split-screen camera (one viewport per character)
- [ ] Hazards, moving platforms, and mirrored switches/doors
- [ ] Mobile touch controls
- [ ] Monetization: cosmetic character skins, optional ad-supported hint system

## Author
**Pinninti Ajay** — [LinkedIn](https://www.linkedin.com/in/pinnintiajay45)

## License
MIT — see [LICENSE](LICENSE).
