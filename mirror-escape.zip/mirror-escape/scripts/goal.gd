extends Area2D

## Emitted the first time a player body enters this goal.
signal reached(goal: Area2D)

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
    if body is CharacterBody2D:
        reached.emit(self)
