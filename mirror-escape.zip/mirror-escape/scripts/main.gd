extends Node2D

@onready var goal_a: Area2D = $GoalA
@onready var goal_b: Area2D = $GoalB
@onready var status_label: Label = $UI/StatusLabel

var a_reached := false
var b_reached := false

func _ready() -> void:
    goal_a.reached.connect(_on_goal_a_reached)
    goal_b.reached.connect(_on_goal_b_reached)

func _on_goal_a_reached(_goal: Area2D) -> void:
    a_reached = true
    _check_win()

func _on_goal_b_reached(_goal: Area2D) -> void:
    b_reached = true
    _check_win()

func _check_win() -> void:
    if a_reached and b_reached:
        status_label.text = "Level Complete! Both mirrored characters reached their goals."
