extends CharacterBody2D

## When true, horizontal input is inverted -- this is the "mirrored" character.
@export var mirrored: bool = false
@export var speed: float = 220.0
@export var jump_velocity: float = -420.0

const GRAVITY := 980.0

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y += GRAVITY * delta

    var direction := Input.get_axis("ui_left", "ui_right")
    if mirrored:
        direction = -direction

    velocity.x = direction * speed

    if Input.is_action_just_pressed("ui_up") and is_on_floor():
        velocity.y = jump_velocity

    move_and_slide()
